<?php
    echo $list;
?>