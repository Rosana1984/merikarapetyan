<?php
/**
 * @version      1.0.0 15.11.2013
 * @author       ZooTemplate
 * @package      Jshopping
 * @copyright    Copyright (C) 2008-2013 zootemplate.com. All rights reserved.
 * @license      GNU/GPL
 */

defined('_JEXEC') or die('Restricted access');
?>
<div class="manufactuter_list<?php echo $moduleclass_sfx; ?>"> 
    <ul id="zt_manufacturer_jshopping<?php echo $module->id;?>" class="zt_manufacturer">
    <?php foreach($list as $curr){ ?>
        <li class="item">
             <a href="<?php echo $curr->link; ?>"> 
				<?php if ($show_image && $curr->manufacturer_logo): ?>
					<img src="<?php echo $jshopConfig->image_manufs_live_path."/".$curr->manufacturer_logo; ?>" alt="<?php echo $curr->name; ?>" />
				<?php endif; ?>
			</a> 
      	</li>
      <?php } ?>
    </ul>  
</div> 
<script type="text/javascript">
    jQuery(document).ready(function() {
        var document_width = jQuery( window ).width();
        var auto = true;
        if(document_width <= 1024)
            auto = false;
        jQuery('#zt_manufacturer_jshopping<?php echo $module->id; ?>').bxSlider({
            minSlides: 1,
            maxSlides: 5,
            moveSlides: 1,
            slideWidth: 184,
            slideMargin: 37,
            auto: auto,
            pause: 1000,
            pager: false
        });
    });
</script>
