<?php
$numberproducts = count($last_prod);
?>
<div class="latest_products">
<?php foreach($last_prod as $curr){ ?>
    <form name="product" method="post" action="<?php print SEFLink('index.php?option=com_jshopping&controller=cart&task=add',1);?>" enctype="multipart/form-data" autocomplete="off">

        <div class="block_item col-md-<?php echo 12/$numberproducts;?> col-sm-6 col-xs-6 ">
           <div class="block_item_inner">
               <div class="block_item_inner_1">
                   <?php if ($show_image) { ?>
                   <div class="item_image">
                       <a href="<?php print $curr->product_link?>"><img src = "<?php print $jshopConfig->image_product_live_path?>/<?php if ($curr->product_thumb_image) print $curr->product_thumb_image; else print $noimage?>" alt="" /></a>
                   </div>
                   <?php } ?>
                   <div class="item_name">
                       <a href="<?php print $curr->product_link?>"><?php print $curr->name?></a>
                   </div>
                   <?php if ($curr->_display_price){?>
                       <div class="item_price">
                           <?php if($curr->product_old_price != null ): ?>
                               <span id="old_price"><?php print formatprice($curr->product_old_price);?></span>
                           <?php endif; ?>
                           <span class="price"><?php print formatprice($curr->product_price);?></span>
                       </div>
                   <?php }?>
                   <input type="submit" class="button_buy" value="<?php print _JSHOP_ADD_TO_CART?>" onclick="jQuery('#to').val('cart');" />
               </div>
               <div class="block_item_infor">
                   <span class="block_item_rating"><?php echo showMarkStar($curr->average_rating)?></span>
                   <span class="block_item_hits"><?php echo $curr->hits?> <?php print _JSHOP_HITS?> </span>
                   <br>
                   <div class="block_item_wish">
                       <button type="submit" title="<?php print _JSHOP_ADD_TO_WISHLIST; ?>" class="button_wishlist"  onclick="jQuery(this).parent().parent().next().val('wishlist');">
                           <i class="fa fa-heart"></i> <span><?php print _JSHOP_ADD_TO_WISHLIST; ?></span>
                       </button>
                   </div>
               </div>
               <input type="hidden" name="to" id='to' value="cart" />
               <input type="hidden" name="product_id" id="product_id" value="<?php print $curr->product_id?>" />
               <input type="hidden" name="category_id" id="category_id" value="<?php print $curr->category_id?>" />
           </div>
       </div>

    </form>
<?php } ?>
</div>