<?php 
/**
* @version      4.3.1 13.08.2013
* @author       MAXXmarketing GmbH
* @package      Jshopping
* @copyright    Copyright (C) 2010 webdesigner-profi.de. All rights reserved.
* @license      GNU/GPL
*/
defined('_JEXEC') or die('Restricted access');
?>
<div class="zt_jshop">


    <div class="zt_list_product">
        <?php foreach ($this->rows as $k=>$product){?>
        <?php if ($k%$this->count_product_to_row==0) print "<div class='row-products row'>";?>
            <div class="block_product col-sm-<?php echo 12/$this->count_product_to_row;?> ">
                <?php include(dirname(__FILE__)."/".$product->template_block_product);?>
            </div>
            <?php if ($k%$this->count_product_to_row==$this->count_product_to_row-1){?>
            </div>
            <?php }?>
        <?php }?>
        <?php if ($k%$this->count_product_to_row!=$this->count_product_to_row-1) print "</div>";?>
    </div>
</div>