<?php 
/**
* @version      4.3.1 13.08.2013
* @author       MAXXmarketing GmbH
* @package      Jshopping
* @copyright    Copyright (C) 2010 webdesigner-profi.de. All rights reserved.
* @license      GNU/GPL
*/
defined('_JEXEC') or die('Restricted access');
?>
<?php
$in_row = $this->config->product_count_related_in_row;
?>
<?php if (count($this->related_prod)){?>
    <div class="zt-jsrelated">
        <h3 class="related_header"><?php print _JSHOP_RELATED_PRODUCTS?></h3>
        <div class="zt_jshop_list_products">
            <div class = "zt_list_product">
                <?php foreach($this->related_prod as $k=>$product){?>
                    <?php if ($k%$in_row==0) print "<div class='row-products row'>";?>
                    <div class="block_product  col-sm-<?php echo 12/$in_row; ?> col-xs-12">
                        <?php include(dirname(__FILE__)."/../".$this->folder_list_products."/".$product->template_block_product);?>
                    </div>
                    <?php if ($k%$in_row==$in_row-1) print "</div>";?>
                <?php }?>
                <?php if ($k%$in_row!=$in_row-1) print "</div>";?>
            </div>
        </div>
    </div>
<?php }?>