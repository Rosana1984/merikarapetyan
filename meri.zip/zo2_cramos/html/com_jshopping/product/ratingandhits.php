<?php 
/**
* @version      4.3.1 13.08.2013
* @author       MAXXmarketing GmbH
* @package      Jshopping
* @copyright    Copyright (C) 2010 webdesigner-profi.de. All rights reserved.
* @license      GNU/GPL
*/
defined('_JEXEC') or die('Restricted access');
?>
<?php if ($this->allow_review || $this->config->show_hits){?>
<div class="zt_jsrating" >

    <?php if ($this->allow_review){?>
        <span class="zt_iconrating">
        <?php print showMarkStar($this->product->average_rating);?>
        </span>
    <?php } ?>
    <?php if ($this->config->show_hits){?>
        <span class="zt_hits"><?php print _JSHOP_HITS?>: <?php print $this->product->hits;?> </span>
    <?php } ?>

</div>
<?php } ?>