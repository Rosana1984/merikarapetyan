
<div id = "zt_module_cart">
    <div class="zt_module_cart_inner">
        <div id="open-cart"><i class="fa fa-shopping-cart"></i></div>
        <div id="zt_module_cart_detail" style="display: none">
            <a href = "<?php print SEFLink('index.php?option=com_jshopping&controller=cart&task=view', 1)?>"><span id = "jshop_quantity_products"><?php print $cart->count_product?> &nbsp;<?php print JText::_('PRODUCTS')?></span></a>
            <br><span id = "jshop_summ_product"><?php print formatprice($cart->getSum(0,1))?></span>
            <div class="gotocart" style="font-weight: bold"><a href = "<?php print SEFLink('index.php?option=com_jshopping&controller=cart&task=view', 1)?>"><?php if($params->get('picture_link')) print '<img src="'.JURI::root().$params->get('picture_link').'" />';?> <?php print JText::_('GO_TO_CART')?></a></div>
        </div>
        <div id="CartOverlay" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; z-index: 1000; opacity: 0.5; -moz-opacity:0.5;"></div>
    </div>
</div>
<script>
    jQuery(document).ready(function($){
        jQuery("#open-cart").click(function(){
            jQuery("#zt_module_cart_detail").slideToggle("700");
            jQuery("#CartOverlay").toggle();
            jQuery("#open-cart").addClass("hover");
        });
        jQuery("#CartOverlay").click(function() {
            jQuery("#zt_module_cart_detail").toggle("fast");
            jQuery("#open-cart").removeClass("hover");
            jQuery(this).toggle();
        });
    });
</script>