<?php
defined('_JEXEC') or die;
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="<?php echo $this->language; ?>" lang="<?php echo $this->language; ?>" dir="<?php echo $this->direction; ?>">
<head>
    <?php echo isset( $header) ?  $header : '' ?>
    <jdoc:include type="head" />
    <link rel="stylesheet" href="<?php echo $this->baseurl; ?>/templates/zo2_cramos/assets/zo2/css/component.css" type="text/css" />

</head>
<body class="contentpane">
<jdoc:include type="message" />
<jdoc:include type="component" />
<script>
    close_btn = document.getElementById('toolbar-cancel');
    close_btn.addEventListener('click', function() {
        window.parent.SqueezeBox.close();
    });
</script>
</body>
</html>

